# Populate external data

- Webflow project: https://preview.webflow.com/preview/fs-attributes-examples?utm_medium=preview_link&utm_source=designer&utm_content=fs-attributes-examples&preview=2ea2b334911b5a83403b5dc40f109b55&pageId=6255be5f111e345d127a9763&workflow=preview

- Live Site: https://fs-attributes-examples.webflow.io/external-data
